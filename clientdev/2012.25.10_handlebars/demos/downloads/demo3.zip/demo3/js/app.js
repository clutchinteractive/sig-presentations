$(document).ready(function() {
    var templateSource = "<h1>{{appName}}</h1>" +
                         "<h2>Hidden == false</h2>" +
                         "<div class='container'>" +
                         "{{#each images}}" +
                            "{{#unless hidden}}" +
                                "<img class='image' src='{{path}}'>" +
                            "{{/unless}}" +
                         "{{/each}}" +
                         "</div>" +
                         "<h2>Hidden == true</h2>" +
                         "<div class='container'>" +
                         "{{#each images}}" +
                            "{{#if hidden}}" +
                                "<img class='image' src='{{path}}'>" +
                            "{{/if}}" +
                         "{{/each}}" +
                         "</div>";

    var template = Handlebars.compile(templateSource);

    var data = {
        appName: "Demo 3",
        images: [
            {hidden: true, path: "images/Chrysanthemum.jpg"},
            {hidden: false, path: "images/Desert.jpg"},
            {hidden: false, path: "images/Hydrangeas.jpg"},
            {hidden: true, path: "images/Jellyfish.jpg"},
            {hidden: false, path: "images/Koala.jpg"},
            {hidden: true, path: "images/Lighthouse.jpg"},
            {hidden: false, path: "images/Penguins.jpg"},
            {hidden: false, path: "images/Tulips.jpg"}
        ]
    };

    $("#templateContainer").html(template(data));
});