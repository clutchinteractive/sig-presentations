$(document).ready(function() {
    var templateSource = "<h1>{{appName}} - {{authors.length}} Authors</h1>" +
                         "<h2>Hidden == false</h2>" +
                         "<div class='container'>" +
                         "{{#each authors}}" +
                            "{{#each images}}" +
                                "{{#unless hidden}}" +
                                    "<div class='imageContainer'>" +
                                        "<img class='image' src='{{path}}'>" +
                                        "<p>Created by {{../../name}}</p>" +
                                    "</div>" +
                                "{{/unless}}" +
                            "{{/each}}" +
                         "{{/each}}" +
                         "</div>" +
                         "<h2>Hidden == true</h2>" +
                         "<div class='container'>" +
                         "{{#each authors}}" +
                            "{{#each images}}" +
                                "{{#if hidden}}" +
                                    "<div class='imageContainer'>" +
                                        "<img class='image' src='{{path}}'>" +
                                        "<p>Created by {{../../name}}</p>" +
                                    "</div>" +
                                "{{/if}}" +
                            "{{/each}}" +
                         "{{/each}}" +
                         "</div>";

    var template = Handlebars.compile(templateSource);

    var data = {
        appName: "Demo 4",
        authors: [
            {
                name: "Bob",
                images: [
                    {hidden: true, path: "images/Chrysanthemum.jpg"},
                    {hidden: false, path: "images/Desert.jpg"},
                    {hidden: false, path: "images/Hydrangeas.jpg"},
                    {hidden: true, path: "images/Jellyfish.jpg"}
                ]
            },
            {
                name: "Jane",
                images: [
                    {hidden: false, path: "images/Koala.jpg"},
                    {hidden: true, path: "images/Lighthouse.jpg"},
                    {hidden: false, path: "images/Penguins.jpg"},
                    {hidden: false, path: "images/Tulips.jpg"}
                ]
            }
        ]
    };

    $("#templateContainer").html(template(data));
});